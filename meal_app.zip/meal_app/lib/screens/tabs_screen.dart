import 'package:flutter/material.dart';
import 'package:meal_app/models/meal.dart';
import 'package:meal_app/screens/categories.dart';
import 'package:meal_app/screens/meals.dart';

class TabsScreen extends StatefulWidget {
  const TabsScreen({super.key});

  @override
  State<TabsScreen> createState() => _TabsScreenState();
}

class _TabsScreenState extends State<TabsScreen> {
  int _selectedPageIndex = 0;

  final List<Meal> _favoriteMeals = [];

  void _selectPage(int index) {
    setState(() {
      _selectedPageIndex = index;
    });
  }

  void _toggleFavoriteMeal(Meal meal) {
    setState(() {
      final index = _favoriteMeals.indexWhere((m) => m.id == meal.id);
      if (index >= 0) {
        _favoriteMeals.removeAt(index);
      } else {
        _favoriteMeals.add(meal);
      }
    });
  }

  bool _isMealFavorite(Meal meal) {
    return _favoriteMeals.any((m) => m.id == meal.id);
  }

  @override
  Widget build(BuildContext context) {
    final pages = [
      CategoriesScreen(
        onToggleFavorite: _toggleFavoriteMeal,
        isFavorite: _isMealFavorite,
      ),
      MealsScreen(
        title: 'Favorites',
        meals: _favoriteMeals,
        onToggleFavorite: _toggleFavoriteMeal,
        isFavorite: _isMealFavorite,
      ),
    ];

    final titles = ['Pick Your Category', 'Your Favorites'];

    return Scaffold(
      appBar: AppBar(title: Text(titles[_selectedPageIndex])),
      body: pages[_selectedPageIndex],
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _selectedPageIndex,
        onTap: _selectPage,
        items: const [
          BottomNavigationBarItem(
            icon: Icon(Icons.category),
            label: 'Categories',
          ),
          BottomNavigationBarItem(icon: Icon(Icons.star), label: 'Favorites'),
        ],
      ),
    );
  }
}
